#!/bin/sh

echo "1 is maand, 2 is week"

read -p "Kies [1] maand of [2] week " keuze
case $keuze in
1)
	sudo sh maandscript.sh
	;;

2)
	sudo sh weekscript.sh
	;;
*)
	echo"Fout, gebruik 1 of 2"
	;;

esac

