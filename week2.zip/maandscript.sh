#!/bin/bash


# Voor inspiratie heb ik wat bronnen gebruikt.
# https://tldp.org/HOWTO/Bash-Prog-Intro-HOWTO.html
# Linux Bash Examples vanuit het Hanze.
# Stack Overflow.






read -p "Tot welke maand? " maand       	#user input voor maand keuze		      	

for i in `seq 1 $maand`;			#for loop door keuze heen te loopen
do
	for x in ~/Fotos/*.jpg				#alle jpeg bestanden in de directory.
	do
		currentmaand=$(date -r "$x" +%m)			#currentmaand 
		if [ "$currentmaand" -le "$maand" ]:			#als current maand less or equal is dan maand gebeurd er niks.	
		then
			if [ -d "$currentmaand"  ];			#Check of directory bestaat.
			then
				cp -v "$x" "./$currentmaand"  		#kopier bestand naar nieuwe directory. 
				oh=$(sudo md5sum "$x" | cut -d " " -f1)
				nh=$(sudo md5sum ./"$currentmaand"/"${x##*/}" | cut -d " " -f1)		## {##*/} alles voor de laatste / wordt verwijderd.

				if [ "$oh" = "$nh" ];			#als original hash gelijk is aan newhash
				then
					rm "$x"				#als equal is mag verwijderd worden.
				else	
					echo "Copy of $x  was unsuccesfull, wont remove old file"
				fi
			else
				mkdir "./$currentmaand"	
				cp -v "$x" "./$currentmaand"            
                                oh=$(sudo md5sum "$x" | cut -d " " -f1)
                                nh=$(sudo md5sum ./"$currentmaand"/"${x##*/}" | cut -d " " -f1)         
 				if [ "$oh" = "$nh" ];                   
                                then
                                        rm "$x"                         
                                else
                                        echo "Copy of $x  was unsuccesfull, wont remove old file"
                                fi

			fi
		fi
	done
done
