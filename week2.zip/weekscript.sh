#!/bin/bash


read -p "Tot welke week? " week			#user input voor week

for i in `seq 1 $week`;				#for loop om door week heen te loopen.
do
for x in ~/Fotos/*.jpg
do
currentweek=$(date -r "$x" +%W)			#currentweek	
if [ "$currentweek" -le "$week" ]:		#als current week less or equal is dan week, gebeurd er niks.
then
if [ -d "$currentweek"  ];		#check of directory bestaat.
then
cp -v "$x" "./$currentweek"  	#kopieer bestand naar nieuwe directory.
oh=$(sudo md5sum "$x" | cut -d " " -f1)		
nh=$(sudo md5sum ./"$currentweek"/"${x##*/}" | cut -d " " -f1)   #alles na laatste / wordt verwijderd.

if [ "$oh" = "$nh" ];   	#als original hash gelijk is aan new hash.
then
					rm "$x"			#als equal is mag verwijderd worden.
else
					echo "Copy of $x  was unsuccesfull, wont remove old file"
fi
else
mkdir "./$currentweek"
cp -v "$x" "./$currentweek"
oh=$(sudo md5sum "$x" | cut -d " " -f1)
nh=$(sudo md5sum ./"$currentweek"/"${x##*/}" | cut -d " " -f1)

if [ "$oh" = "$nh" ];
then
rm "$x"
else
echo "Copy of $x  was unsuccesfull, wont remove old file"
fi

fi
fi
done
done
